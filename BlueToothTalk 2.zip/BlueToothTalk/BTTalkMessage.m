//
//  BTTalkMessage.m
//  BlueToothTalk
//
//  Created by developer on 27/06/13.
//  Copyright (c) 2013 CPT. All rights reserved.
//

#import "BTTalkMessage.h"

@implementation BTTalkMessage

@end
