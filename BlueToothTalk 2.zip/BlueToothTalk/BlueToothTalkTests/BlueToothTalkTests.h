//
//  BlueToothTalkTests.h
//  BlueToothTalkTests
//
//  Created by developer on 25/06/13.
//  Copyright (c) 2013 CPT. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface BlueToothTalkTests : SenTestCase

@end
