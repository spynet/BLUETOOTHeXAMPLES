//
//  BTTalkAppDelegate.h
//  BlueToothTalk
//
//  Created by developer on 25/06/13.
//  Copyright (c) 2013 CPT. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BTTalkViewController;

@interface BTTalkAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) BTTalkViewController *viewController;

@end
