//
//  main.m
//  BlueToothTalk
//
//  Created by developer on 25/06/13.
//  Copyright (c) 2013 CPT. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BTTalkAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BTTalkAppDelegate class]));
    }
}
