//
//  BlueToothTalkTests.m
//  BlueToothTalkTests
//
//  Created by developer on 25/06/13.
//  Copyright (c) 2013 CPT. All rights reserved.
//

#import "BlueToothTalkTests.h"

@implementation BlueToothTalkTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in BlueToothTalkTests");
}

@end
